give @s minecraft:music_disc_13[minecraft:jukebox_playable="namedrecords:golden",minecraft:item_name="Golden"]
