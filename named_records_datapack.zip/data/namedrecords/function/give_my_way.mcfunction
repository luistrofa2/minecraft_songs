give @s minecraft:music_disc_creator_music_box[minecraft:jukebox_playable="namedrecords:my_way",minecraft:item_name="My Way"]
